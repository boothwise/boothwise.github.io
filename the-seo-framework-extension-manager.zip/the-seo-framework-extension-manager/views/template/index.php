<?php
/**
 * The visionary starts with a clean sheet of paper,
 * and reimagines the world.
 *
 * - Malcolm Gladwell
 */
