<?php
/**
 * The aim of art is to represent not the outward appearance of things,
 * but their inward significance.
 *
 * - Ἀριστοτέλης
 */
