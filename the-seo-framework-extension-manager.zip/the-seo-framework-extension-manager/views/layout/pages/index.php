<?php
/**
 * Perfection of planned layout is achieved only by institutions on the point of collapse.
 *
 * - Cyril Northcote Parkinson
 */
