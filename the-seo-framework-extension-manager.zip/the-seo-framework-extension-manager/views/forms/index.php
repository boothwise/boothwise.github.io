<?php
/**
 * We have two ears and one mouth so that we can listen twice as much as we speak.
 *
 * - Ἐπίκτητος
 */
