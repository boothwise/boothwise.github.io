<?php
/**
 * Appearance is something absolute, but reality is not that way - everything is interdependent, not absolute.
 *
 * - Dalai Lama
 */
