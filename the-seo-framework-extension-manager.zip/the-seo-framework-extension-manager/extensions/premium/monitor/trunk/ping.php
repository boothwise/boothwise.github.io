<?php
/*
defined( 'ABSPATH' ) or die;

//* Remove WebEngine headers.
@header_remove();

//* Send 202 and cache control.
@http_response_code( 202 );

// session_cache_limiter( 'nocache' ); :
@header( 'Expires: Thu, 19 Nov 1981 08:52:00 GMT' );
@header( 'Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0' );
@header( 'Pragma: no-cache' );
@header( 'Date: ' . gmdate( 'D, d M Y H:i:s' ) . ' GMT' );

//* Deliver a little bit of content.
echo "\n";

//* Done.
exit;
*/
