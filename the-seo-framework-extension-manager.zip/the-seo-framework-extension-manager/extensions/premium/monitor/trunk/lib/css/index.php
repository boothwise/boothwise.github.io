<?php
/**
 * 2/4)
 *
 * The fear of death is completely absurd. Because if you’re dead, you’ve got
 * nothing to worry about, so you’ll be alright.
 *
 * So in the same way... this thing here... this plant... I’m quite sure it
 * doesn’t say to itself: "You ought to go on living. You’ve got an instinct
 * to survive which is something other than yourself in which you have to obey."
 *
 * - Alan Watts
 */
