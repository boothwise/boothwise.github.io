<?php
/**
 * 1/4)
 *
 * And what is it all about? Well, we say, one must live. It’s necessary to survive.
 * You know, you really must go on: It’s your duty.
 *
 * We think, in other words, part of our Western philosophy, that we think we
 * have a drive to survive, that we must go on living; because some Big Daddy said to us:
 * "You gotta go on living."... See! "And you better make it or else!"
 *
 * There really is no necessity to go on living.
 *
 * - Alan Watts
 */
