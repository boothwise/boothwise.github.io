<?php
/**
 * 4/4)
 *
 * If I were to ask my wife: "Darling, do you really love me?", and she says:
 * "I’m trying my best to do so," it’s not the answer I want.
 *
 * I want her to say: "I can’t help loving you, I love you so much I could eat you.".
 *
 * And that’s what the plant feels in growing; it doesn’t feel that it must grow,
 * it’s not under orders, it’s not a military chain of commands. It does this
 * spontaneously, so that when you try to command this spontaneous process, you stop it.
 *
 * - Alan Watts
 */
