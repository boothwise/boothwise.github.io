<?php
/**
 * The true university of these days is a collection of books.
 *
 * - Thomas Carlyle
 */
