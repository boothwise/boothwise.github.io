<?php
/**
 * 3/4)
 *
 * Now you see, living, like this plant, is something spontaneous.
 *
 * In Chinese, the word for nature is "Zì Rán," which means "that which happens
 * of itself; not under any control of any outside boss."
 *
 * And so, you stop this spontaneous flowering of nature cold if you tell it: "You must do it!"
 * It’s like saying to someone: "You must love me!"... Well, it’s ridiculous!
 *
 * - Alan Watts
 */
