<?php
/**
 * Trust in dreams, for in them is hidden the gate to eternity.
 *
 * - Khalil Gibran
 */
