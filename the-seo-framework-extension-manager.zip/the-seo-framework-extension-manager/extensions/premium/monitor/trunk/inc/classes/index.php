<?php
/**
 * Cities are just a physical manifestation of your interactions, our interactions,
 * and the clustering and grouping of individuals.
 *
 * - Geoffrey West
 */
