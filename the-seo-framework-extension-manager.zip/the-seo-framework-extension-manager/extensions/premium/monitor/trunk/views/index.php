<?php
/**
 * The important thing is that men should have a purpose in life.
 * It should be something useful, something good.
 *
 * - Dalai Lama
 */
