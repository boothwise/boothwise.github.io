<?php
/**
 * Listen to many, speak to a few.
 *
 * - William Shakespeare
 */
