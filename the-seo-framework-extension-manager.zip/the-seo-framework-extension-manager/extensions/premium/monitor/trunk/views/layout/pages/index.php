<?php
/**
 * The true mystery of the world is the visible, not the invisible.
 *
 * - Oscar Wilde
 */
