<?php
/**
 * Intelligence is the ability to adapt to change.
 *
 * - Stephen Hawking
 */
