<?php
/**
 * Moral excellence comes about as a result of habit. We become just by doing
 * just acts, temperate by doing temperate acts, brave by doing brave acts.
 *
 * - Ἀριστοτέλης
 */
