<?php
/**
 * It is a capital mistake to theorize before one has data.
 *
 * - Arthur Conan Doyle
 */
