<?php
/**
 * This world is but a canvas to our imagination.
 *
 * - Henry David Thoreau
 */
