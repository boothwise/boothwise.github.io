<?php
/**
 * Things are not always as they seem; the first appearance deceives many.
 *
 * - Plato
 */
