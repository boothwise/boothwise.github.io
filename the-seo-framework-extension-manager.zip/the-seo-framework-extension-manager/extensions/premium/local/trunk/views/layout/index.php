<?php
/**
 * Better keep yourself clean and bright; you are the window through which
 * you must see the world.
 *
 * - George Bernard Shaw
 */
