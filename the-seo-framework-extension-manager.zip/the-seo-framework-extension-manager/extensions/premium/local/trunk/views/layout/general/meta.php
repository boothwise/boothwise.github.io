<?php
/**
 * @package TSF_Extension_Manager\Extension\Local\Admin\Views
 */

defined( 'ABSPATH' ) and $_class = \TSF_Extension_Manager\Extension\Local\get_layout_class() and $this instanceof $_class or die;

//* So fancy.
?>
<meta name="theme-color" content="#0ebfe9" />
<meta name="msapplication-navbutton-color" content="#0ebfe9" />
<meta name="apple-mobile-web-app-status-bar-style" content="#0ebfe9" />
<?php
