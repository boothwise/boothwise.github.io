<?php
/**
 * Every dance is a kind of fever chart, a graph of the heart.
 *
 * - Martha Graham
 */
