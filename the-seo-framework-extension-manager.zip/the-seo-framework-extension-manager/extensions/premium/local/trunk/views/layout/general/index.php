<?php
/**
 * We are not permitted to choose the frame of our destiny.
 * But what we put into it is ours.
 *
 * - Dag Hammarskjöld
 */
