<?php
/**
 * I think that in any group activity - whether it be business, sports,
 * or family - there has to be leadership or it won't be successful.
 *
 * - John Wooden
 */
