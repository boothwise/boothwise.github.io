<?php
/**
 * Science is a way of thinking much more than it is a body of knowledge.
 *
 * - Carl Sagan
 */
