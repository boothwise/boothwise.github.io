<?php
/**
 * The secret I've lived by ever since I started earning money is this:
 * Always buy a house with an extra bedroom adjoined the master. And that's always
 * my closet.
 *
 * - Polly Bergem
 */
