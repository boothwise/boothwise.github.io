<?php
/**
 * When love and skill work together, expect a masterpiece.
 *
 * - John Ruskin
 */
