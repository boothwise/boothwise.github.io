<?php
/**
 * 4/4)
 *
 * Only I see now that it's not gonna be a material goody; all material goodies fall apart...
 * and maybe there's a spiritual goody that's not going to fall apart.
 * But, in that quest, the quest is not different from the quest for the candy bar:
 * Same old story - only you refined the candy bar, made it abstract and holy and blessed and so on.
 *
 * So, it is with a higher self: the higher self's your own ego.
 * And you sure hope it is eternal, indestructable and all-wise.
 *
 * - Alan Watts
 */
