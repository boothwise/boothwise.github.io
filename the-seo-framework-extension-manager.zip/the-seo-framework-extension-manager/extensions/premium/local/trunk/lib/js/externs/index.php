<?php
/**
 * The desire to annoy no one, to harm no one, can equally well be the sign
 * of a just as of an anxious disposition.
 *
 * - Friedrich Nietzsche
 */
