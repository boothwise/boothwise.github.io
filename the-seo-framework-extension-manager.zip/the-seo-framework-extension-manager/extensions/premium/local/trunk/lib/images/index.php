<?php
/**
 * 2/4)
 *
 * When the police enter a house in which there are thieves,
 * the thieves go up from the ground floor to the first floor.
 * When the police arrive on the first floor, the thieves have gone up to the second,
 * and so to the third and finally out to the roof.
 * And so, when the ego is about to be unmasked, it immediately identifies with a higher self.
 * It goes up a level.
 *
 * - Alan Watts
 */
