<?php
/**
 * Don't let ambition get so far ahead that it loses sight of the job at hand.
 *
 * - William Feather
 */
