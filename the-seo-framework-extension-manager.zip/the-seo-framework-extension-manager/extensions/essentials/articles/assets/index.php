<?php
/**
 * Art is not what you see, but what you make others see.
 *
 * - Edgar Degas
 */
