<?php
/**
 * I lead from the heart, not the head.
 *
 * - Diana Frances, Princess of Wales
 */
