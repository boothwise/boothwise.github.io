<?php
/**
 * History will be kind to me for I intend to write it.
 *
 * - Winston Churchill
 */
