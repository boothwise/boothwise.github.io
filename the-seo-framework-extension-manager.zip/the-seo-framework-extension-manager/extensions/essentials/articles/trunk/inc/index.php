<?php
/**
 * When I write, I can shake off all my cares.
 * My sorrow disappears, my spirits are revived!
 *
 * But, and that’s a big question, will I ever be able to write something great,
 * will I ever become a journalist or a writer?
 *
 * - Anne Frank
 */
