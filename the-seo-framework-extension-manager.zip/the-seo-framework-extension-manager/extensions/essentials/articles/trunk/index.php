<?php
/**
 * There is nothing to writing. All you do is sit down at a typewriter and bleed.
 *
 * - Ernest Hemingway
 */
