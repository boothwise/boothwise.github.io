<?php
/**
 * The opportunity for doing mischief is found a hundred times a day,
 * and of doing good once in a year.
 *
 * - François-Marie "Voltaire" Arouet
 */
