<?php
/**
 * The creative process is the same secret in science as it is in art.
 * They are all the same absolutely.
 *
 * - Josef Albers
 */
