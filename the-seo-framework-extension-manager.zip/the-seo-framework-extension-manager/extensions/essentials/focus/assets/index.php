<?php
/**
 * Create your own visual style...
 * let it be unique for yourself, and yet identifiable for others.
 *
 * - Orson Welles
 */
