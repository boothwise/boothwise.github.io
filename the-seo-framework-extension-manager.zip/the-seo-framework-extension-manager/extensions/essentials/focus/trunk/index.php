<?php
/**
 * You can't depend on your eyes when your imagination is out of focus.
 *
 * - Mark Twain
 */
