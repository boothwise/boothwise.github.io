<?php
/**
 * The third eye witnesses the internal screen where memory and fantasy,
 * images and archetypes, intuition and imagination intertwine on endless display.
 *
 * - Anodea Judith
 */
