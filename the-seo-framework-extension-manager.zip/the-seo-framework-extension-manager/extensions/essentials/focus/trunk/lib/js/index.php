<?php
/**
 * The university brings out all abilities, including incapability.
 *
 * - Anton Chekhov
 */
