<?php
/**
 * Wear a smile and have friends; wear a scowl and have wrinkles.
 *
 * - George ELiot
 */
