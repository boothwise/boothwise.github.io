<?php
/**
 * With data collection, "The sooner the better" is always the best answer.
 *
 * - Marissa Mayer
 */
