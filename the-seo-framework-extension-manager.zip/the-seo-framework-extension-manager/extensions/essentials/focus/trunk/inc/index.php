<?php
/**
 * Being fully present is the best guarantee for a bright future.
 *
 * - Guy Finley
 */
