<?php
/**
 * The best way to medidate is through meditation itself.
 *
 * - Ramana Maharshi
 */
