<?php
/**
 * Evil is a miscellaneous collection of nasty things that nasty people do.
 *
 * - Richard Dawkins
 */
