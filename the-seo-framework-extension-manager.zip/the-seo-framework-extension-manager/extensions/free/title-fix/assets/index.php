<?php
/**
 * Once an object has been incorporated in a picture it accepts a new destiny.
 *
 * - Georges Braque
 */
