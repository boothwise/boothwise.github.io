<?php
/**
 * For to win one hundred victories in one hundred battles is not the acme of skill.
 * To subdue the enemy without fighting is the acme of skill.
 *
 * - 孫子
 */
