<?php
/**
 * Three things cannot be long hidden: the sun, the moon, and the truth.
 *
 * - Buddha
 */
