<?php
/**
 * Vision is the art of seeing what is invisible to others.
 *
 * - Jonathan Swift
 */
