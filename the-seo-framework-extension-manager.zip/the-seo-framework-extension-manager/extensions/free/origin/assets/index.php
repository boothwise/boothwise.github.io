<?php
/**
 * I know this is gonna look like we're destroying everything;
 * don't worry about it:
 * We don't make mistakes... we have happy accidents.
 *
 * - Bob Ross
 */
