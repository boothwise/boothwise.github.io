<?php
/**
 * There's about to be an amazing shift in your life.
 *
 * - Ralph Smart
 */
