<?php
/**
 * There is more to life than simply increasing its speed.
 *
 * - Mahatma Gandhi
 */
