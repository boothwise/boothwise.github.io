<?php
/**
 * One can have no smaller or greater mastery than mastery of oneself.
 *
 * - Leonardo da Vinci
 */
