<?php
/**
 * Insanity: doing the same thing over and over again and expecting different results.
 *
 * - Albert Einstein
 */
