<?php
/**
 * Today different ethnic groups and different nations come together due to common sense.
 *
 * - Dalai Lama
 */
