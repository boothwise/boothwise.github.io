<?php
/**
 * Want het groote geschiedt niet bij impulsie alleen en is een aaneenschakeling
 * van kleine dingen die tot elkaar gebragt zijn.
 *
 * (For the great doesn’t happen through impulse alone, and is a succession
 * of little things that are brought together.)
 *
 * - Vincent Willem van Gogh
 *
 * [ˈvɪnsɛnt ˈʋɪləm vɑn ˈɣɔx] - Learn to pronounce his name correctly:
 * https://en.wikipedia.org/wiki/File:Vincent_willem_van_gogh.ogg
 */
