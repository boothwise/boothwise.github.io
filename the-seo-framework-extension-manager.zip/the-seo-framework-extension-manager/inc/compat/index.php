<?php
/**
 * A weed is a plant that has mastered every survival skill except for learning
 * how to grow in rows.
 *
 * - Doug Larson
 */
