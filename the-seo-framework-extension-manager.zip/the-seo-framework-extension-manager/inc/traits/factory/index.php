<?php
/**
 * One who neglects or disregards the existence of earth, air, fire,
 * water, and vegetation disregards his own existence which is entwined with them.
 *
 * - Mahavira
 */
