<?php
/**
 * Excellence is not a skill, it's an attitude.
 *
 * - Ralph Martson
 */
