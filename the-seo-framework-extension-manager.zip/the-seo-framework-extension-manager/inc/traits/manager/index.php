<?php
/**
 * It's OK to have your eggs in one basket,
 * as long as you control what happens to that basket.
 *
 * - Elon Musk
 */
