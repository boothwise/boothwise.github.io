<?php
/**
 * Whatever affects one directly, affects all indirectly.
 * I can never be what I ought to be until you are what you ought to be.
 * This is the interrelated structure of reality.
 *
 * - Martin Luther King, Jr.
 */
