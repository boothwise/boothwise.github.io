<?php
/**
 * The need for connection and community is primal,
 * as fundamental as the need for air, water, and food.
 *
 * - Dean Ornish
 */
