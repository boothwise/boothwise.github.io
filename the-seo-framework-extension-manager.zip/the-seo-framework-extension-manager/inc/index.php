<?php
/**
 * The secreting or hoarding of knowledge or information may be an act of
 * tyranny camouflaged as humility.
 *
 * - Robin Morgan
 */
