<?php
/**
 * Language has created the word 'loneliness' to express the pain of being alone.
 * And it has created the word 'solitude' to express the glory of being alone.
 *
 * - Paul Tillich
 */
