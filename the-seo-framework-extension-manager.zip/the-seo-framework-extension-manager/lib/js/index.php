<?php
/**
 * 4/4)
 *
 * That would be within the infinite multiplicity of choices you would have.
 * Of playing that you weren't God.
 * Because the whole nature of the godhead, according to this idea, is to play that he is not.
 *
 * So in this idea then, everybody is fundamentally the ultimate reality,
 * not God in a politically kingly sense, but God in the sense of being the self,
 * the deep-down basic whatever there is.
 *
 * And you are all that, only you are pretending you are not.
 *
 * - Alan Watts
 */
