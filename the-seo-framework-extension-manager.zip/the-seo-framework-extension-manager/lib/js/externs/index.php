<?php
/**
 * People who work together will win, whether it be against complex football
 * defenses, or the problems of modern society.
 *
 * - Vince Lombardi
 */
