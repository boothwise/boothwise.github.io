<?php
/**
 * No story lives unless someone wants to listen...
 * The stories we love best do live in us forever.
 *
 * - J.K. Rowling
 */
