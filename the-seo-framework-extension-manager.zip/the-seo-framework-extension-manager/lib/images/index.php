<?php
/**
 * 3/4)
 *
 * But now let’s have a surprise:
 * Let’s have a dream which isn’t under control, where something is gonna happen to me that I don’t know what it's gonna be.
 * And you would dig that and would come out of that and you would say “Wow that was a close shave, wasn’t it?”.
 *
 * And then you would get more and more adventurous and you would make further- and further-out gambles what you would dream.
 *
 * And finally, you would dream where you are now.
 * You would dream the dream of living the life that you are actually living today.
 *
 * - Alan Watts
 */
