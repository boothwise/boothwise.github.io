<?php
/**
 * 1/4)
 *
 * If you awaken from this illusion and you understand that black implies white,
 * self implies other, life implies death (or shall I say death implies life?)...
 * you can feel yourself –
 * not as a stranger in the world, not as something here on probation,
 * not as something that has arrived here by fluke -
 * but you can begin to feel your own existence as absolutely fundamental.
 *
 * What you are basically, deep, deep down, far, far in,
 * is simply the fabric and structure of existence itself.
 *
 * - Alan Watts
 */
