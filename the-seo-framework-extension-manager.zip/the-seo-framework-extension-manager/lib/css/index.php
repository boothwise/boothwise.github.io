<?php
/**
 * 2/4)
 *
 * Let’s suppose that you were able every night to dream any dream you wanted to dream,
 * and that you could for example have the power within one night to dream 75 years of time,
 * or any length of time you wanted to have.
 *
 * And you would, naturally, as you began on this adventure of dreams,
 * you would fulfill all your wishes.
 * You would have every kind of pleasure during your sleep.
 * And after several nights - of 75 years of total pleasure each -
 * you would say “Well that was pretty great”.
 *
 * - Alan Watts
 */
