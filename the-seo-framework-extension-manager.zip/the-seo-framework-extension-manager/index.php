<?php
/**
 * The true sign of intelligence is not knowledge, but the power of imagination.
 *
 * - Albert Einstein
 */
